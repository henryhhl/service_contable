
import React from 'react';
import AppRoute from './routes/appRoute';

function App() {
    return (
        <>
            <AppRoute />
        </>
    );
}

export default App;
